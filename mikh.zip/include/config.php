<?php 
if(substr($_SERVER["REQUEST_URI"], -10) == "config.php"){header("Location:./");}; 
$data['mikhmon'] = array ('1'=>'mikhmon<|<admin','mikhmon>|>fJKgoWdjZmBe');

$data['Cloudnet.id'] = array ('1'=>'Cloudnet.id!id-02.tunnel.web.id:7727','Cloudnet.id@|@admin','Cloudnet.id#|#fJKgoWdjZmBe','Cloudnet.id%Cloudnet.id','Cloudnet.id^tekaje.id','Cloudnet.id&Rp','Cloudnet.id*10','Cloudnet.id(1','Cloudnet.id)','Cloudnet.id=disable','Cloudnet.id@!@disable');

