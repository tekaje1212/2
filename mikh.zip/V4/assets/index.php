<?php
include_once("../core/page_route.php");
include_once("../core/func.php");
e403();